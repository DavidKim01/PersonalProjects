const http = require('http');
const https = require('https');
const url = require('url');
const fs = require('fs');
const credentials = require('./auth/credentials.json');
const querystring = require('querystring');

const server_address = 'localhost';
const port = 3000;
const authentication_cache = './auth/authentication-res.json';
const item_type_index_cache = './cache/item-type-index-res.json';
const item_types_cache = './cache/item-types-cache.json';
const item_sets_cache_dir = './cache/';
const icons_cache_dir = './cache/images/icons/';
const portrait_icons_cache_dir = './cache/images/class-portraits/'
const user_locale = 'en_US'; //doc: can add regions later 


const generate_random_int = function(max){
    return Math.floor(Math.random() * (max + 1));
};

const request_authentication = function (user_class, user_gender, res){

	let post_data = querystring.stringify(credentials);

	const options = {
		'method':"POST",
		'headers':{
		'Content-Type': 'application/x-www-form-urlencoded',
		'Content-Length': post_data.length
		}
	}
	
	console.log("Retrieving Token");

	let cache_valid = false;
	if (fs.existsSync(authentication_cache)) {
		cached_auth = require(authentication_cache); //since the authentication_cache.json file exists we can now import it.
		if (new Date(cached_auth.expiration) > Date.now()) { //if the token property expiration has not yet passed the current time/date...
			cache_valid = true; //it has not yet expired, so set the cache validity to true. The cache is still fresh enough (it is less than an hour old.)
		}
		else { //Otherwise the token has expired and leave the cache_valid variable at false, denoting that it has expired.
			console.log('Token Expired');
		}
	}
	
	if (cache_valid){
		create_item_type_index_req(cached_auth, user_class, user_gender, res);
	}

	else {
		const token_endpoint = 'https://us.battle.net/oauth/token';
		let auth_sent_time = new Date();
		let authentication_req = https.request(token_endpoint, options, function (authentication_res) {
			received_authentication(authentication_res, user_class, user_gender, auth_sent_time, res);
			//console.log("CALLBACK CHECK for CACHE functionality: New Request Caught for authentication cache!"); //testing purposes
		});
		
		authentication_req.on('error', function (e) {console.error(e);});
		authentication_req.end(post_data);
	}
};

const received_authentication = function(authentication_res, user_class, user_gender, auth_sent_time, res){
	authentication_res.setEncoding("utf8");
	let body = "";
	authentication_res.on("data", function (chunk){body += chunk;});
	authentication_res.on("end", function (){
		let blizzard_auth = JSON.parse(body);
		blizzard_auth.expiration = auth_sent_time.getTime() + 86400000;
        create_access_token_cache(blizzard_auth);
        create_item_type_index_req(blizzard_auth, user_class, user_gender, res);
	});
};

const connection_established = function(req, res){
	console.log(`request was made: ${req.url}`);

	if (req.url === "/"){
		let html_stream = fs.createReadStream('./html/class-selection.html');
		res.writeHead(200, {'Content-Type':'text/html'});
		html_stream.pipe(res);
	}
	else if (req.url.startsWith('/cache/images/')){
		let image_stream = fs.createReadStream(`.${req.url}`);
		image_stream.on('error', function(err) {
		 	console.log(err);
		 	res.writeHead(404);
		 	return res.end();
		 });
		res.writeHead(200, {'Content-Type':'image/jpeg'});
		image_stream.pipe(res);
	}
	else if (req.url.startsWith("/chest")){
		let user_class = url.parse(req.url,true).query.class;
		let user_gender = url.parse(req.url,true).query.gender;
		request_authentication(user_class, user_gender, res);
		res.writeHead(200,{'Content-Type':'text/html'});
	}
	else {
		res.writeHead(404);
		res.end();
	}
};

const create_access_token_cache = function (blizzard_auth){
	let data = JSON.stringify(blizzard_auth);
	fs.writeFile(authentication_cache, data, (err) => {
		if(err) throw err;
	});
};


const create_item_type_index_req = function(blizzard_auth, user_class, user_gender, res){
    console.log("Retrieving Item Type Index");
	let cache_valid = false;
	
	if (fs.existsSync(item_type_index_cache)) {
		cached_item_type_index = require(item_type_index_cache); //since the authentication_cache.json file exists we can now import it.
		cache_valid = true;
	}
	
	if (cache_valid){
        separate_class_types(cached_item_type_index, blizzard_auth, user_class, user_gender, res);
	}

	else {
        //`https://us.api.blizzard.com/d3/data/item-type?locale=${user_locale}&access_token=US8rOC7O5uidZ4vHib8YlvYJqMnwjIRAju`
		const item_type_index_req_endpoint = `https://us.api.blizzard.com/d3/data/item-type?locale=en_US&access_token=${blizzard_auth.access_token}`;

		let item_type_index_req = https.request(item_type_index_req_endpoint, function (item_type_index_res) {
			get_item_type_index(item_type_index_res, blizzard_auth, user_class, user_gender, res);
            console.log("CALLBACK CHECK for CACHE functionality: New Request Caught for item type index cache!"); //testing purposes
        });
		
		item_type_index_req.on('error', function (e) {console.error(e);});
		item_type_index_req.end();
	}
};

const get_item_type_index = function(item_type_index_res, blizzard_auth, user_class, user_gender, res){
    item_type_index_res.setEncoding("utf8");
	let body = "";
	item_type_index_res.on("data", function (chunk){body += chunk;});
	item_type_index_res.on("end", function (){
		let item_type_index = JSON.parse(body);
        create_item_type_index_cache(item_type_index);
        separate_class_types(item_type_index, blizzard_auth, user_class, user_gender, res);
    });
};

const create_item_type_index_cache = function (item_type_index){
    let data = JSON.stringify(item_type_index);
	fs.writeFile(item_type_index_cache, data, (err) => {
		if(err) throw err;
	});
};

const separate_class_types = function(item_type_index, blizzard_auth, user_class, user_gender, res){
	if (fs.existsSync(item_types_cache)) {
		cached_item_types = require(item_types_cache); //imports the cached json as a javascript object to be passed into the generate_class_set method.
		generate_class_set(cached_item_types, blizzard_auth, user_class, user_gender, res);
	}
	else{
		let barbarian_items = {}, demonhunter_items = {}, monk_items = {}, witchdoctor_items = {}, wizard_items = {}, other_items = {};
		let barbarian_count = 0, demonhunter_count = 0, monk_count = 0, witchdoctor_count = 0, wizard_count = 0, other_count = 0;
		
		for(let i = 0; i<item_type_index.length; i++){
			if(item_type_index[i].id.includes("Barbarian")){
				barbarian_items[barbarian_count] = item_type_index[i].path;
				barbarian_count++;
			}
			else if(item_type_index[i].id.includes("DemonHunter")){
				demonhunter_items[demonhunter_count] = item_type_index[i].path;
				demonhunter_count++;
			}
			else if(item_type_index[i].id.includes("Monk")){
				monk_items[monk_count] = item_type_index[i].path;
				monk_count++;
			}
			else if(item_type_index[i].id.includes("WitchDoctor")){
				witchdoctor_items[witchdoctor_count] = item_type_index[i].path;
				witchdoctor_count++;
			}
			else if(item_type_index[i].id.includes("Wizard")){
				wizard_items[wizard_count] = item_type_index[i].path;
				wizard_count++;
			}
			else if(item_type_index[i].id.includes("Crusader") || item_type_index[i].id.includes("Necromancer") || item_type_index[i].id == "Gold" || item_type_index[i].id == "PortalDevice" || item_type_index[i].id == "Quest" ||item_type_index[i].id == "GeneralUtility" || item_type_index[i].id =="CraftingPlan_MysticTransmog"){
				continue;
			}
			else{
				other_items[other_count] = item_type_index[i].path;
				other_count++;
			}
		}
		let item_types = {};
		item_types.barbarian = barbarian_items;
		item_types.demonhunter = demonhunter_items;
		item_types.monk = monk_items;
		item_types.witchdoctor = witchdoctor_items;
		item_types.wizard = wizard_items;
		item_types.other = other_items;
	
		let data = JSON.stringify(item_types);
		fs.writeFile(item_types_cache, data, (err) => {
			if(err) throw err;
			generate_class_set(item_types, blizzard_auth, user_class, user_gender, res);
		});
	}
    
};

const generate_class_set =  function(item_types, blizzard_auth, user_class, user_gender, res){
	let class_item_sets_count = Object.keys(item_types[user_class]).length - 1;
	let random_class_set_num = generate_random_int(class_item_sets_count);
	let random_class_set_path = item_types[user_class][random_class_set_num];
	let chosen_class_set_path = `${item_sets_cache_dir}${random_class_set_path}`;

	// console.log("Class set size: " + class_item_sets_count);
	// console.log("Random class set number: " + random_class_set_num);
	// console.log("Random class set path: " + random_class_set_path);
	// console.log("Retrieving Class Item");

    let cache_valid = false;
	if (fs.existsSync(`${chosen_class_set_path}.json`)) {
		cached_class_item_set = require(`${chosen_class_set_path}.json`);
		cache_valid = true;
	}
	
	if (cache_valid){
		generate_class_item(cached_class_item_set, item_types, blizzard_auth, user_class, user_gender, res);
	}

	else {
		//https://us.api.blizzard.com/d3/data/item-type/sword2h?locale=en_US&access_token=US98sfIKTFoRNyQ2EF3KeEI6k3KDCAZnYE endpoint example for the sword2h item set json
		const class_item_set_req_endpoint = `https://us.api.blizzard.com/d3/data/${random_class_set_path}?locale=en_US&access_token=${blizzard_auth.access_token}`;
		let class_item_set_req = https.request(class_item_set_req_endpoint, function (class_item_set_res) {
			get_class_item_set(class_item_set_res, chosen_class_set_path, item_types, blizzard_auth, user_class, user_gender, res);
            //console.log("CALLBACK CHECK for CACHE functionality: New Request Caught for class item set cache!");
        });
		
		class_item_set_req.on('error', function (e) {console.error(e);});
		class_item_set_req.end();
	}
};

const get_class_item_set = function(class_item_set_res, chosen_class_set_path, item_types, blizzard_auth, user_class, user_gender, res){
    class_item_set_res.setEncoding("utf8");
	let body = "";
	class_item_set_res.on("data", function (chunk){body += chunk;});
	class_item_set_res.on("end", function (){
		let class_item_set = JSON.parse(body);
        create_class_item_set_cache(class_item_set, chosen_class_set_path);
        generate_class_item(class_item_set, item_types, blizzard_auth, user_class, user_gender, res);
    });
};

const create_class_item_set_cache = function(class_item_set, chosen_class_set_path){
	let data = JSON.stringify(class_item_set);
	fs.writeFile(`${chosen_class_set_path}.json`, data, (err) => {
		if(err) throw err;
	});
};

const generate_class_item = function(class_item_set, item_types, blizzard_auth, user_class, user_gender, res){
	let items_and_names_arr = [];
	let curr_array = [];

	let random_class_item_set_size = Object.keys(class_item_set).length-1;
	
	let random_class_item_num = generate_random_int(random_class_item_set_size);
	let name = class_item_set[random_class_item_num]['name'];
	let icon_path = class_item_set[random_class_item_num]['icon'];
	curr_array.push(name+` (Your Unique Class Item!)`, icon_path);
	items_and_names_arr.push(curr_array);
	
	generate_item_sets(items_and_names_arr, item_types, blizzard_auth, user_class, user_gender, res);
};

const generate_item_sets = function(items_and_names_arr, item_types, blizzard_auth, user_class, user_gender, res){
	
	let other_item_sets_count = Object.keys(item_types['other']).length - 1;
	let items_set = 0;
	let item_limit = 3;
	

	for(let i = 0; i < item_limit; i++){
		let random_other_item_set_num = generate_random_int(other_item_sets_count);
		let random_other_item_set_path = item_types['other'][random_other_item_set_num];
		let chosen_item_set_path = `${item_sets_cache_dir}${random_other_item_set_path}`;
		let other_item_set_req_endpoint = `https://us.api.blizzard.com/d3/data/${random_other_item_set_path}?locale=en_US&access_token=${blizzard_auth.access_token}`;
		// console.log("Other item set size: " + other_item_sets_count);
		// console.log("Random item set number: " + random_other_item_set_num);
		// console.log("Random item set path: " + random_other_item_set_path);
		// console.log("Retrieving Other Items");

		let cache_valid = false;
		if (fs.existsSync(`${chosen_item_set_path}.json`)) {
			cached_other_item_set = require(`${chosen_item_set_path}.json`);
			cache_valid = true;
		}
		
		if (cache_valid){
			let curr_array = [];
			let random_other_item_set_size = Object.keys(cached_other_item_set).length-1;
			let random_other_item_num = generate_random_int(random_other_item_set_size);

			let name = cached_other_item_set[random_other_item_num]['name'];
			let icon_path = cached_other_item_set[random_other_item_num]['icon'];
			
			if(random_other_item_num <= (random_other_item_set_size/5)){
				curr_array.push(name+' (Rare)', icon_path);
			}
			else{
				curr_array.push(name, icon_path);
			}
			items_and_names_arr.push(curr_array);

			items_set++;
			if(items_set == item_limit){
				download_item_icons(items_and_names_arr, user_class, user_gender, res);
			}
		}
	
		else {
			let other_item_set_req = https.request(other_item_set_req_endpoint, function (other_item_set_res) {

				other_item_set_res.setEncoding("utf8");
				let body = "";
				other_item_set_res.on("data", function (chunk){body += chunk;});
				other_item_set_res.on("end", function (){
					let other_item_set = JSON.parse(body);
					let data = JSON.stringify(other_item_set);
					fs.writeFile(`${chosen_item_set_path}.json`, data, (err) => {
						if(err) throw err;
					});

					let curr_array = [];
					let random_other_item_set_size = Object.keys(other_item_set).length-1;
					let random_other_item_num = generate_random_int(random_other_item_set_size);
					let name = other_item_set[random_other_item_num]['name'];
					let icon_path = other_item_set[random_other_item_num]['icon'];
					if(random_other_item_num <= (random_other_item_set_size/5)){
						curr_array.push(name+' (Rare)', icon_path);
					}
					else{
						curr_array.push(name, icon_path);
					}
					items_and_names_arr.push(curr_array);
		
					items_set++;
					if(items_set == item_limit){
						download_item_icons(items_and_names_arr, user_class, user_gender, res);
					}
				});
			});
			
			other_item_set_req.on('error', function (e) {console.error(e);});
			other_item_set_req.end();
		}
	}

};

const download_item_icons = function(items_and_names_arr, user_class, user_gender, res){
	let downloaded_icons = 0;
	let item_count = items_and_names_arr.length;
	let icon_size = 'large'; //can either be small or large.

	for (let i = 0; i < item_count; i++){
		let icon_name = items_and_names_arr[i][1];
		let icon_url = `http://media.blizzard.com/d3/icons/items/${icon_size}/${icon_name}.png`;
		let icon_path = `${icons_cache_dir}${icon_name}.png`;
		fs.access(icon_path, function(err){
			if(err){
				let icon_req = http.get(icon_url, function(icon_res){
					//console.log("CALLBACK CHECK for CACHE functionality: New Request Caught for img cache!"); ////testing purposes
					let new_icon = fs.createWriteStream(icon_path, {'encoding':null});
					icon_res.pipe(new_icon);
					new_icon.on("finish", function() {
						downloaded_icons++;
						if(downloaded_icons === item_count){
							get_class_icon(items_and_names_arr, user_class, user_gender, res);
						}
					});
				});
				icon_req.on('error', function(err){console.log(err);});
				//console.log("Requesting a new image(not found in cache)...");
				icon_req.end();
			}
			else{
				//console.log("Cache Hit: File found!");
				downloaded_icons++;
				if(downloaded_icons === item_count){
					get_class_icon(items_and_names_arr, user_class, user_gender, res);
				}
			}
		});

	}
};
const get_class_icon =  function(items_and_names_arr, user_class, user_gender, res){
	let portrait_size = 64; //can either be 21(small), 42(medium), or 64(large).
	let portrait_name = `${user_class}_${user_gender}`;
	let portrait_url = `http://media.blizzard.com/d3/icons/portraits/${portrait_size}/${portrait_name}.png`;	
	let portrait_path = `${portrait_icons_cache_dir}${portrait_name}.png`;

	fs.access(portrait_path, function(err){
		if(err){
			//console.log("Requesting a new class portrait(not found in cache)...");
			let portrait_req = http.get(portrait_url, function(portrait_res){
				let new_portrait = fs.createWriteStream(portrait_path, {'encoding':null});
				portrait_res.pipe(new_portrait);
				new_portrait.on("finish", function() {
					generate_loot_page(items_and_names_arr, user_class, portrait_path, res);
				});
			});
			portrait_req.on('error', function(err){console.log(err);});
			portrait_req.end();
		}
		else{
			//console.log("Portrait cache icon hit!")
			generate_loot_page(items_and_names_arr, user_class, portrait_path, res);
		}
	});
};

const generate_loot_page = function(items_and_names_arr, user_class, portrait_path, res){
	let capitalized_class = user_class.charAt(0).toUpperCase() + user_class.slice(1);
	let raw_html = `<h1>Your ${capitalized_class} (<img src="${portrait_path}">) opened...</h1>`;
	tagged_elements_array = items_and_names_arr.map(function(e) {
		let result =  `<img src="${icons_cache_dir}${e[1]}.png" /><h3>${e[0]}</h3>`;
		return result;
	})
	raw_html += tagged_elements_array.join('');
	res.end(raw_html);
}

const connectionStart = function(){
	console.log(`Now Listening on Port ${port}`);
};

const server = http.createServer(connection_established);

server.on("listening", connectionStart);
server.listen(port, server_address);