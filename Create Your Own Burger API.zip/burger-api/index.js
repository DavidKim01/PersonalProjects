const http = require("http");
//Note: We are not requesting data from another api so https is not required here just http
const fs = require("fs");
const url = require("url");

//npm dependencies
const jimp = require("jimp");

const port = 3000;
const host = "localhost";

let server = http.createServer((req,res)=>{
    console.log(`Request was made: ${req.method} ${req.url}`)//we can do this to extract the req method that was used
    if (req.url === "/"){
        let home = fs.createReadStream("./html/index.html");
        home.on("error", (err)=>{
            console.log(err);
            res.end(404);
        });
        res.writeHead(200, {"Content-Type":"text/html"});
        home.pipe(res); //Remember, its: readstream.pipe(writestream)
    }
    else if (req.url.startsWith("/build")){
        let order = "";
        order = url.parse(req.url,true).query.q;
        console.log(order);
        open_assets(order,res);
    }
});

const open_assets = function(order, res){
    const assets = [{id: "b", path:"assets/bun.png"}, ////assets represented as an array of objects
                    {id: "p", path:"assets/patty.png"},
                    {id: "l", path:"assets/lettuce.png"},
                    {id: "c", path:"assets/cheese.png"},
                    {id: "t", path:"assets/tomato.png"},
                    {id: "e", path:"assets/egg.png"}];                
    let assets_read = 0;
    assets.map(asset => { //read like a for each...for each asset perform the block statements
        jimp.read(asset.path, (err, resource)=>{
            if(err) throw err;
            asset.resource  = resource//resource handler or how you interact with that object, add a resource property to each assets object
            //This is asynch, so it will run in parallel almost
            assets_read++;
            if(assets_read === assets.length){
                parse_order(order, assets, res);
            }
        });
    });
};

const parse_order =  function (order, assets, res){
    let burger = [];
    //we just want the ids so use this common technique to extract only the ids from assets object array, in functional programming we call this flattening:
    let ids = assets.map(x => x.id);//returns an array of just the map elements in each asset object
    console.log(order);
    Array.from(order).map((letter)=>{
        let i = ids.indexOf(letter);
        if (i !== -1){ //error handling for invalid file types, if a letter doesnt exist in assets -1 will be returned(e.g. console.log(ids.indexOf("z")) prints -1;)
            burger.push(assets[i]);
        }
    });
    create_burger(burger, order, res);
    //Array.from("HelloWorld"); will return (10) ["H", "e", "l", "l", "o", "W", "o", "r", "l", "d"]
    //you can also use the spread operator,[..."HelloWorld"];, and it will return the same thing.
    
}
const create_burger = function (burger, order, res){
    let height = 130 + (25*burger.length-1);
    new jimp(326 , height , (err, canvas) => {
        if (err) throw err;
        let yaxis = 0;
        for(component of burger) {
            canvas.blit(component.resource , 0, yaxis);
            yaxis += 25;
        }
        canvas.flip(false,true).write(`cache/${order}.png`, ()=>{ //canvas.flip(horiz = false, vert = true).write(...) vs canvas.write(...)
            //canvas.rotate() should also work
            let burger_stream = fs.createReadStream(`cache/${order}.png`);
            res.writeHead(200, {"Content-Type":"image/jpeg"});
            burger_stream.pipe(res);
        });
    });
};

server.listen(port, host);
console.log(`Now Listening On Port ${port}`);
let assets = open_assets();//optimization:call open_assets function as soon as the server starts